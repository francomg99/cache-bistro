import reflex as rx

def black_line() -> rx.Component:
    return rx.divider(
        height="6em",
        bg="#060606"
    )