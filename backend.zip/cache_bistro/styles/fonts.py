from enum import Enum


class Font(Enum):
    DEFAULT = "Roboto Condensed"
    TITLE = "Bebas Neue"

